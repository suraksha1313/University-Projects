#!/usr/bin/env python3

import cv2
import numpy as np

def process_image(image_path, lower_color, upper_color, min_blob_area, color_name):
    # Load the image
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Could not load the image at '{image_path}'.")
        exit()

    # Convert the image to HSV
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # Create a mask for the specified color range
    color_mask = cv2.inRange(hsv_image, lower_color, upper_color)

    # Find contours in the mask
    contours, _ = cv2.findContours(color_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Iterate through the contours and filter based on area
    blob_count = 0

    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_blob_area:
            # Draw bounding box around the blob
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
            blob_count += 1

    # Print the count of blobs
    print(f"Number of {color_name} blobs:", blob_count)

    # Display the result
    cv2.imshow(f'{color_name} Blobs with Bounding Boxes', image)
    cv2.waitKey(10000)  # Wait for 3 seconds
    cv2.destroyAllWindows()
    # Add a delay to keep the script running
    cv2.waitKey(0)

# Prompt user to choose which point to process using character input
print("Enter 'A' for blue image or 'B' for pink image:")
user_choice = input().upper()

# Process the chosen image
if user_choice == 'A':
    process_image('/home/ros/catkin_ws/src/surmuji477/blues.png', np.array([98, 82, 0]), np.array([255, 255, 255]), 100, 'Blue')
elif user_choice == 'B':
    process_image('/home/ros/catkin_ws/src/surmuji477/pink.jpg', np.array([145, 54, 13]), np.array([255, 255, 255]), 100, 'Pink')
else:
    print("Invalid choice. Exiting.")
