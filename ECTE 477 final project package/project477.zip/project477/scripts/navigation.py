#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import PoseStamped, Quaternion
from std_msgs.msg import String
from sensor_msgs.msg import Image
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge
import cv2
import numpy as np
from datetime import datetime

class TurtleBot3Navigation:
    def __init__(self):
        rospy.init_node('turtlebot3_navigation', anonymous=True)

        # Initialize variables
        self.current_pose = None
        self.bridge = CvBridge()

        # Subscribe to TurtleBot3 odometry
        rospy.Subscriber('/odom', Odometry, self.odom_callback)

        # Prompt user to choose which point to process using character input
        print("Enter 'A' to go to point A or 'B' to go to point B:")
        user_choice = input().upper()

        # Process the chosen image
        self.user_choice_callback(String(data=user_choice))

    def odom_callback(self, odom_msg):
        # Get the current pose of the robot
        self.current_pose = odom_msg.pose.pose

    def user_choice_callback(self, choice_msg):
        user_choice = choice_msg.data.upper()

        if user_choice == 'A':
            self.move_to_goal(0.5551636219024658, 1.0034269094467163,0.9956241846084595, 0.09344759583473206, [98, 82, 0], [255, 255, 255], 100, 'Blue')
        elif user_choice == 'B':
            self.move_to_goal(2.475958824157715, 0.5897204279899597, -0.0081336051225566223, 0.9999669194221497, [145, 54, 13], [255, 255, 255], 100, 'Pink')
        else:
            print("Invalid choice. Exiting.")

    def move_to_goal(self, x, y, z, w, lower_color, upper_color, min_blob_area, color_name):
        # Publish a navigation goal to move_base
        goal_pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)
        goal_msg = PoseStamped()
        goal_msg.pose.position.x = x
        goal_msg.pose.position.y = y
        goal_msg.pose.position.z = 0.0  # Assuming 2D navigation, adjust as needed
        goal_msg.pose.orientation = Quaternion(z=z, w=w)
        goal_msg.header.frame_id = 'map'

        rospy.sleep(2)  # Wait for the move_base to initialize
        goal_pub.publish(goal_msg)
        rospy.sleep(30)  # Adjust the delay as needed

        # Take a snapshot after reaching the destination
        self.take_snapshot(lower_color, upper_color, min_blob_area, color_name)

    def take_snapshot(self, lower_color, upper_color, min_blob_area, color_name):
        # Wait for the robot to stabilize
        rospy.sleep(2)

        # Capture image from the USB camera
        image_msg = rospy.wait_for_message('/usb_cam/image_raw', Image)
        cv_image = self.bridge.imgmsg_to_cv2(image_msg, desired_encoding='bgr8')

        # Save the image with a timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        image_filename = f'/home/ros/catkin_ws/src/project477/snapshot_{timestamp}.png'
        cv2.imwrite(image_filename, cv_image)

        # Process the captured image
        self.process_image(image_filename, np.array(lower_color), np.array(upper_color), min_blob_area, color_name)

    def process_image(self, image_path, lower_color, upper_color, min_blob_area, color_name):
        # Load the image and perform color blob counting
        image = cv2.imread(image_path)
        if image is None:
            print(f"Error: Could not load the image at '{image_path}'.")
            return

        # Convert the image to HSV
        hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Create a mask for the specified color range
        color_mask = cv2.inRange(hsv_image, lower_color, upper_color)

        # Find contours in the mask
        contours, _ = cv2.findContours(color_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Iterate through the contours and filter based on area
        blob_count = 0

        for contour in contours:
            area = cv2.contourArea(contour)
            if area > min_blob_area:
                # Draw bounding box around the blob
                x, y, w, h = cv2.boundingRect(contour)
                cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
                blob_count += 1

        # Print the count of blobs
        print(f"Number of {color_name} blobs:", blob_count)

        # Display the result
        cv2.namedWindow(f'{color_name} Blobs with Bounding Boxes', cv2.WINDOW_NORMAL)
        cv2.resizeWindow(f'{color_name} Blobs with Bounding Boxes', 800, 600)  # Adjust the size as needed
        cv2.imshow(f'{color_name} Blobs with Bounding Boxes', image)

        cv2.waitKey(60000)  # Wait for 60 seconds
        cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        turtlebot3_navigation = TurtleBot3Navigation()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass